<?php
// ════════════════════════════════════════════════════════════════
//  GERADOR DE LICENÇA — Quadro Investigador
//  USE APENAS VOCÊ (DESENVOLVEDOR)
//  Execute: php gerador_licenca.php
// ════════════════════════════════════════════════════════════════

// Chave carregada do arquivo seguro (mesma pasta config do investigador)
define('LIC_APP', 'INVESTIGADOR_V6');
require_once __DIR__ . '/../investigador/config/lic_secret.php';

function generateCode(string $machineId): string {
    $h = strtoupper(hash_hmac('sha256', strtoupper($machineId), LIC_SECRET));
    return implode('-', str_split(substr($h, 0, 40), 8));
}

// ── Interface web simples ──
if (php_sapi_name() !== 'cli') {
    $code = '';
    $mid  = '';
    if (!empty($_POST['machine_id'])) {
        $mid  = strtoupper(str_replace(['-', ' ', "\n", "\r"], '', trim($_POST['machine_id'])));
        $code = generateCode($mid);
    }
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🛠️ Gerador de Licença — Investigador</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#050a0f;font-family:'Segoe UI',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:linear-gradient(160deg,#0a1520,#050d18);border:2px solid #1a4a6b;border-radius:16px;padding:42px 40px;max-width:680px;width:100%;box-shadow:0 0 60px rgba(0,100,200,.2),0 0 120px rgba(0,0,0,.8);text-align:center}
.logo{font-size:2.8rem;margin-bottom:8px}
h1{color:#30a0e0;font-size:1.4rem;letter-spacing:2px;margin-bottom:4px;text-shadow:0 0 18px rgba(48,160,224,.5)}
.subtitle{color:#256a8a;font-size:.78rem;margin-bottom:32px;letter-spacing:1px;color:#c0392b;font-weight:bold}
label{display:block;color:#1a6a9a;font-size:.7rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;text-align:left}
textarea{width:100%;background:#020810;border:2px solid #0d3050;border-radius:8px;color:#4db8ff;padding:14px 16px;font-family:'Courier New',monospace;font-size:.85rem;letter-spacing:2px;outline:none;transition:border-color .2s;margin-bottom:16px;resize:vertical;min-height:90px}
textarea:focus{border-color:#30a0e0;box-shadow:0 0 14px rgba(48,160,224,.2)}
.gen-btn{width:100%;background:linear-gradient(135deg,#0a4a7a,#1a6aaa);border:none;color:#fff;padding:14px;border-radius:8px;font-size:1rem;font-weight:700;cursor:pointer;letter-spacing:1.5px;transition:all .2s;text-transform:uppercase;margin-bottom:24px}
.gen-btn:hover{background:linear-gradient(135deg,#0d5a8a,#2a7aba);box-shadow:0 0 20px rgba(30,120,200,.4)}
.result-label{color:#1a6a9a;font-size:.7rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;text-align:left}
.code-box{background:#020810;border:2px solid #1a5a3a;border-radius:10px;padding:20px;font-family:'Courier New',monospace;font-size:1.1rem;letter-spacing:3px;color:#2ddf8a;text-shadow:0 0 12px rgba(45,223,138,.4);word-break:break-all;line-height:1.9;margin-bottom:10px;user-select:all}
.empty-box{background:#020810;border:2px dashed #0d3050;border-radius:10px;padding:20px;color:#0d3050;font-size:.85rem;margin-bottom:10px}
.copy-btn{background:#0d3050;border:1px solid #1a6aaa;color:#4db8ff;padding:8px 22px;border-radius:6px;cursor:pointer;font-size:.78rem;transition:all .15s;display:inline-block}
.copy-btn:hover{background:#1a5080;color:#80d8ff;border-color:#4db8ff}
.warning{background:#1a0505;border:1px solid #7a1010;border-radius:8px;padding:14px;color:#cc3333;font-size:.76rem;margin-top:28px;line-height:1.7}
</style>
</head>
<body>
<div class="box">
  <div class="logo">🛠️</div>
  <h1>GERADOR DE LICENÇA</h1>
  <p class="subtitle">⚠️ USO EXCLUSIVO DO DESENVOLVEDOR — NÃO COMPARTILHE</p>

  <form method="POST">
    <label>Cole o ID da Máquina do cliente:</label>
    <textarea name="machine_id" placeholder="Cole aqui o ID completo enviado pelo cliente..."><?= htmlspecialchars($mid) ?></textarea>
    <button type="submit" class="gen-btn">🔑 GERAR CÓDIGO DE ATIVAÇÃO</button>
  </form>

  <?php if ($code): ?>
    <label class="result-label">✅ Código de Ativação Gerado:</label>
    <div class="code-box" id="code-result"><?= $code ?></div>
    <button class="copy-btn" onclick="copyCode()">📋 Copiar Código</button>
  <?php else: ?>
    <div class="empty-box">O código de ativação aparecerá aqui após gerar.</div>
  <?php endif; ?>

  <div class="warning">
    ⚠️ <strong>ATENÇÃO:</strong> Este gerador é de uso exclusivo do desenvolvedor.<br>
    Nunca compartilhe este arquivo com clientes. Cada código gerado é único para um computador específico.<br>
    Se o cliente instalar em outro PC, ele precisará de um novo código.
  </div>
</div>
<?php if ($code): ?>
<script>
function copyCode(){
  navigator.clipboard.writeText(<?= json_encode($code) ?>).then(()=>{
    const b=document.querySelector('.copy-btn');
    b.textContent='✅ Copiado!';
    setTimeout(()=>b.textContent='📋 Copiar Código',2000);
  });
}
</script>
<?php endif; ?>
</body>
</html>
<?php
    exit;
}

// ── Interface CLI ──
echo "\n";
echo "╔══════════════════════════════════════════════════╗\n";
echo "║   GERADOR DE LICENÇA — Quadro Investigador       ║\n";
echo "╚══════════════════════════════════════════════════╝\n\n";

echo "Cole o ID da Máquina do cliente (pressione Enter duas vezes para finalizar):\n> ";
$mid = '';
while (true) {
    $line = rtrim(fgets(STDIN), "\r\n");
    if ($line === '') break;
    $mid .= $line;
}

$mid = strtoupper(str_replace(['-', ' '], '', trim($mid)));
if (!$mid) {
    echo "❌ ID inválido.\n";
    exit(1);
}

$code = generateCode($mid);

echo "\n";
echo "════════════════════════════════════════════════════\n";
echo "✅ CÓDIGO DE ATIVAÇÃO:\n\n";
echo "   $code\n\n";
echo "════════════════════════════════════════════════════\n";
echo "Envie este código ao cliente.\n\n";
