<?php
// ════════════════════════════════════════════════════════════════
//  CHAVE SECRETA — Quadro Investigador
//  Este arquivo é carregado internamente pelo index.php
//  Acesso web bloqueado via .htaccess nesta pasta
// ════════════════════════════════════════════════════════════════

// Proteção: bloqueia acesso direto via URL
if (!defined('LIC_APP')) {
    http_response_code(403);
    die('Acesso negado.');
}

// Chave armazenada ofuscada (XOR) — não altere
function _buildLicSecret(): string {
    $b = [0x18,0x59,0x55,0x5e,0x2b,0x46,0x00,0x17,
          0x65,0x53,0x13,0x1f,0x7b,0x61,0x12,0x13,
          0x23,0x04,0x57,0x49,0x13,0x01,0x58,0x30,
          0x63,0x07,0x11,0x58,0x79,0x6a,0x58,0x2a];
    $s = 'Q7#mX2!p';
    $r = '';
    foreach ($b as $i => $v) {
        $r .= chr($v ^ ord($s[$i % strlen($s)]));
    }
    return $r;
}

define('LIC_SECRET', _buildLicSecret());
