<?php
// ════════════════════════════════════════════════════════════════
//  SISTEMA DE LICENÇA POR MÁQUINA — Quadro Investigador
//  NÃO REMOVA OU ALTERE ESTE BLOCO
// ════════════════════════════════════════════════════════════════

// ── Chave carregada de arquivo seguro separado (NÃO está aqui) ──
define('LIC_APP',    'INVESTIGADOR_V6');
define('LIC_FILE',   __DIR__ . '/license.dat');
define('TRIAL_FILE', __DIR__ . '/trial.dat');
define('TRIAL_DAYS', 7);
require_once __DIR__ . '/config/lic_secret.php';  // LIC_SECRET definido aqui

// ── Gera ID único da máquina (hostname + MAC + volume serial) ──
function getMachineId(): string {
    $parts = [];
    $parts[] = php_uname('n'); // hostname

    if (PHP_OS_FAMILY === 'Windows') {
        $raw = @shell_exec('getmac /fo csv /nh 2>nul');
        if ($raw) {
            preg_match_all('/([0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2}-[0-9A-F]{2})/i', $raw, $m);
            if (!empty($m[1])) $parts[] = $m[1][0];
        }
        $vol = @shell_exec('vol C: 2>nul');
        if ($vol) {
            preg_match('/([0-9A-F]{4}-[0-9A-F]{4})/i', $vol, $mv);
            if (!empty($mv[1])) $parts[] = $mv[1];
        }
    } else {
        $raw = @shell_exec('cat /sys/class/net/eth0/address 2>/dev/null') ?:
               @shell_exec('ifconfig 2>/dev/null | grep -oE "([0-9a-f]{2}:){5}[0-9a-f]{2}" | head -1') ?? '';
        $parts[] = trim($raw);
        $uuid = @shell_exec('blkid 2>/dev/null | grep -oP "UUID=\"[^\"]+\"" | head -1') ?? '';
        $parts[] = trim($uuid);
    }

    $raw = LIC_APP . '|' . implode('|', array_filter($parts));
    return strtoupper(hash('sha256', $raw));
}

// ── Gera código de ativação a partir do Machine ID ──
function generateCode(string $machineId): string {
    $h = strtoupper(hash_hmac('sha256', $machineId, LIC_SECRET));
    return implode('-', str_split(substr($h, 0, 40), 8));
}

// ── Valida código digitado pelo usuário ──
function validateCode(string $machineId, string $inputCode): bool {
    $clean    = strtoupper(str_replace(['-', ' '], '', $inputCode));
    $expected = strtoupper(str_replace('-', '', generateCode($machineId)));
    return hash_equals($expected, $clean);
}

// ── Lê licença salva ──
function readLicense(): array {
    if (!file_exists(LIC_FILE)) return [];
    $raw  = file_get_contents(LIC_FILE);
    $data = json_decode(base64_decode($raw), true);
    return is_array($data) ? $data : [];
}

// ── Salva licença ──
function saveLicense(string $machineId, string $code): void {
    $data = ['mid' => $machineId, 'code' => $code, 'app' => LIC_APP, 'ts' => time()];
    file_put_contents(LIC_FILE, base64_encode(json_encode($data)));
}

// ── Verifica se está licenciado ──
function isLicensed(): bool {
    $lic = readLicense();
    if (empty($lic['mid']) || empty($lic['code'])) return false;
    $currentMid = getMachineId();
    if ($lic['mid'] !== $currentMid) return false;
    return validateCode($currentMid, $lic['code']);
}

// ── Funções de Trial ──
function readTrial(): array {
    if (!file_exists(TRIAL_FILE)) return [];
    $raw  = file_get_contents(TRIAL_FILE);
    $data = json_decode(base64_decode($raw), true);
    return is_array($data) ? $data : [];
}
function startTrial(): void {
    $data = ['start' => time(), 'app' => LIC_APP];
    file_put_contents(TRIAL_FILE, base64_encode(json_encode($data)));
}
function getTrialStatus(): string {
    $t = readTrial();
    if (empty($t['start'])) return 'none';
    $elapsed = time() - (int)$t['start'];
    return ($elapsed < TRIAL_DAYS * 86400) ? 'active' : 'expired';
}
function trialDaysLeft(): int {
    $t = readTrial();
    if (empty($t['start'])) return 0;
    $left = TRIAL_DAYS - floor((time() - (int)$t['start']) / 86400);
    return max(0, (int)$left);
}

// ── Handler AJAX de ativação ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lic_action'])) {
    header('Content-Type: application/json');
    if ($_POST['lic_action'] === 'activate') {
        $mid  = getMachineId();
        $code = trim($_POST['lic_code'] ?? '');
        if (validateCode($mid, $code)) {
            saveLicense($mid, $code);
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'msg' => 'Código inválido. Verifique e tente novamente.']);
        }
    }
    if ($_POST['lic_action'] === 'start_trial') {
        if (getTrialStatus() === 'none') {
            startTrial();
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'msg' => 'Período de teste já utilizado.']);
        }
        exit;
    }
    exit;
}

// ── Lógica principal: licença + trial ──
$trialStatus = getTrialStatus();

// Trial ativo: deixa o sistema abrir normalmente
if (!isLicensed() && $trialStatus === 'active') {
    // Cai no resto do código (app principal carrega abaixo)
    goto APP_START;
}

// ── Exibe tela de ativação (sem licença e sem trial ativo) ──
if (!isLicensed()) {
    $machineId    = getMachineId();
    $midFormatted = implode('-', str_split($machineId, 8));
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ativação — Quadro Investigador</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0500;font-family:'Segoe UI',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:linear-gradient(160deg,#1e0c00,#120800);border:2px solid #6b3a10;border-radius:16px;padding:42px 40px;max-width:660px;width:100%;box-shadow:0 0 60px rgba(180,80,0,.35),0 0 120px rgba(0,0,0,.8);text-align:center}
.logo{font-size:3rem;margin-bottom:8px}
h1{color:#e0a030;font-size:1.5rem;letter-spacing:2px;margin-bottom:4px;text-shadow:0 0 18px rgba(224,160,48,.5)}
.subtitle{color:#8a5a25;font-size:.8rem;margin-bottom:32px;letter-spacing:1px}
.mid-label{color:#7a4a1a;font-size:.7rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px}
.mid-box{background:#060200;border:2px solid #3a1f05;border-radius:10px;padding:20px;margin-bottom:8px;font-family:'Courier New',monospace;font-size:1.1rem;letter-spacing:4px;word-break:break-all;line-height:2;color:#ff9f2f;text-shadow:0 0 12px rgba(255,140,0,.5);user-select:all;cursor:text}
.mid-raw{color:#5a3a15;font-size:.66rem;letter-spacing:1px;margin-bottom:22px}
.copy-btn{background:#2e1800;border:1px solid #6b3a10;color:#d4943a;padding:8px 22px;border-radius:6px;cursor:pointer;font-size:.78rem;transition:all .15s;margin-bottom:30px;display:inline-block}
.copy-btn:hover{background:#4a2600;color:#ffe090;border-color:#d4943a}
.divider{border:none;border-top:1px solid #2a1505;margin:28px 0}
.act-label{color:#7a4a1a;font-size:.7rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:12px}
.code-input{width:100%;background:#060200;border:2px solid #4a2800;border-radius:8px;color:#ffb84d;padding:14px 16px;font-family:'Courier New',monospace;font-size:1rem;letter-spacing:2px;text-align:center;outline:none;transition:border-color .2s;margin-bottom:14px}
.code-input:focus{border-color:#d4943a;box-shadow:0 0 14px rgba(212,148,58,.2)}
.act-btn{width:100%;background:linear-gradient(135deg,#7a3000,#b34a00);border:none;color:#fff;padding:14px;border-radius:8px;font-size:1rem;font-weight:700;cursor:pointer;letter-spacing:1.5px;transition:all .2s;text-transform:uppercase}
.act-btn:hover{background:linear-gradient(135deg,#a04000,#e06000);box-shadow:0 0 20px rgba(200,80,0,.4)}
.msg{margin-top:14px;font-size:.84rem;min-height:22px}
.msg.err{color:#ff6644}
.msg.ok{color:#5ddf7a}
.footer{color:#3a2010;font-size:.68rem;margin-top:28px;line-height:1.7}
.trial-btn{width:100%;background:linear-gradient(135deg,#1a4a1a,#2a7a2a);border:2px solid #3aaa3a;color:#aaffaa;padding:13px;border-radius:8px;font-size:.95rem;font-weight:700;cursor:pointer;letter-spacing:1px;transition:all .2s;margin-top:14px}
.trial-btn:hover{background:linear-gradient(135deg,#2a6a2a,#3aaa3a);box-shadow:0 0 20px rgba(0,180,0,.35);color:#fff}
.trial-sep{border:none;border-top:1px dashed #2a3a2a;margin:20px 0}
.trial-note{color:#4a7a4a;font-size:.7rem;margin-top:6px}
.expired-box{background:#1a0505;border:2px solid #aa2020;border-radius:10px;padding:18px 20px;margin-bottom:24px;color:#ff7070;font-size:.88rem;line-height:1.7}
.expired-box strong{color:#ffaaaa;font-size:1rem}
</style>
</head>
<body>
<div class="box">
  <div class="logo">🔍</div>
  <h1>QUADRO INVESTIGADOR</h1>
  <p class="subtitle">SOFTWARE PROTEGIDO — ATIVAÇÃO NECESSÁRIA</p>

  <?php if ($trialStatus === 'expired'): ?>
  <div class="expired-box">
    ⏰ <strong>Período de teste encerrado!</strong><br>
    Seus 7 dias de avaliação expiraram.<br>
    Para continuar usando o sistema, solicite seu código de ativação abaixo.
  </div>
  <?php endif; ?>

  <p class="mid-label">🖥️ ID desta máquina (envie ao desenvolvedor)</p>
  <div class="mid-box" id="mid-display"><?php
    // Exibe em 4 linhas de 16 chars cada
    $chunks = str_split($midFormatted, 18);
    echo implode("\n", $chunks);
  ?></div>
  <div class="mid-raw">ID: <?= $midFormatted ?></div>
  <button class="copy-btn" onclick="copyId()">📋 Copiar ID da Máquina</button>

  <hr class="divider">

  <p class="act-label">🔑 Cole aqui o código de ativação recebido</p>
  <input type="text" class="code-input" id="lic-code" maxlength="55"
         placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX"
         autocomplete="off" spellcheck="false"
         oninput="this.value=this.value.toUpperCase()">
  <button class="act-btn" onclick="ativar()">✅ ATIVAR AGORA</button>
  <div class="msg" id="msg-ativ"></div>

  <?php if ($trialStatus === 'none'): ?>
  <hr class="trial-sep">
  <button class="trial-btn" onclick="iniciarTrial()">🕐 Testar por 7 dias gratuitamente</button>
  <p class="trial-note">Sem necessidade de código. O sistema abrirá por 7 dias.</p>
  <?php endif; ?>

  <div class="footer">
    Envie o <strong style="color:#6b3a10">ID da Máquina</strong> acima para o administrador.<br>
    Você receberá um <strong style="color:#6b3a10">Código de Ativação</strong> exclusivo para este computador.<br>
    Cada licença é válida apenas para <strong style="color:#6b3a10">um computador</strong>.<br><br>
    <a href="mailto:kellogical1@proton.me?subject=Solicitar%20Ativa%C3%A7%C3%A3o%20%E2%80%94%20Quadro%20Investigador&body=Ol%C3%A1%2C%20preciso%20de%20um%20c%C3%B3digo%20de%20ativa%C3%A7%C3%A3o.%0A%0AMeu%20ID%20de%20m%C3%A1quina%3A%20" id="email-btn" class="copy-btn" style="text-decoration:none;display:inline-block;margin-top:6px" onclick="appendMidToLink(this)">
      📧 Enviar e-mail para o Administrador
    </a>
  </div>
</div>
<script>
const MID = <?php echo json_encode($midFormatted); ?>;
function copyId(){
  navigator.clipboard.writeText(MID).then(()=>{
    const b=document.querySelector('.copy-btn');
    b.textContent='✅ Copiado!';
    setTimeout(()=>b.textContent='📋 Copiar ID da Máquina',2000);
  });
}
async function ativar(){
  const code=document.getElementById('lic-code').value.trim();
  const msg=document.getElementById('msg-ativ');
  if(!code){msg.className='msg err';msg.textContent='Digite o código de ativação.';return;}
  msg.className='msg';msg.textContent='Verificando...';
  const fd=new FormData();
  fd.append('lic_action','activate');
  fd.append('lic_code',code);
  try{
    const r=await fetch('',{method:'POST',body:fd});
    const j=await r.json();
    if(j.ok){
      msg.className='msg ok';msg.textContent='✅ Ativação concluída! Abrindo o sistema...';
      setTimeout(()=>location.reload(),1600);
    } else {
      msg.className='msg err';msg.textContent='❌ '+(j.msg||'Código inválido.');
    }
  }catch(e){msg.className='msg err';msg.textContent='Erro. Tente novamente.';}
}
document.getElementById('lic-code').addEventListener('keydown',e=>{if(e.key==='Enter')ativar();});
function appendMidToLink(el){
  const mid = document.getElementById('mid-display').innerText.replace(/\n/g,'').replace(/\s/g,'');
  el.href = el.href.split('ID%20de%20m%C3%A1quina%3A%20')[0]
    + 'ID%20de%20m%C3%A1quina%3A%20' + encodeURIComponent(mid);
}
async function iniciarTrial(){
  const btn = document.querySelector('.trial-btn');
  if(!btn) return;
  btn.disabled = true;
  btn.textContent = '⏳ Iniciando...';
  const fd = new FormData();
  fd.append('lic_action','start_trial');
  try{
    const r = await fetch('', {method:'POST', body:fd});
    const j = await r.json();
    if(j.ok){
      btn.textContent = '✅ Abrindo o sistema...';
      setTimeout(()=>location.reload(), 1200);
    } else {
      btn.textContent = '❌ ' + (j.msg||'Erro ao iniciar trial.');
    }
  } catch(e){
    btn.textContent = '❌ Erro. Tente novamente.';
    btn.disabled = false;
  }
}
</script>
</body>
</html>
<?php
    exit;
}
// ════════════════════════════════════════════════════════════════
APP_START:
// ─── UPLOAD HANDLER ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['imagem'])) {
    header('Content-Type: application/json');
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $ext = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) { echo json_encode(['success'=>false,'msg'=>'Tipo não permitido']); exit; }
    $filename = uniqid('img_') . '.' . $ext;
    $target = $uploadDir . $filename;
    if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target)) {
        echo json_encode(['success' => true, 'url' => 'uploads/' . $filename]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Falha ao salvar']);
    }
    exit;
}
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🔍 Quadro Investigador</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<style>
/* ════════════════════════════════════════
   RESET & BASE
════════════════════════════════════════ */
*{box-sizing:border-box;margin:0;padding:0}
body{background:#120900;font-family:'Segoe UI',sans-serif;overflow:hidden;height:100vh;width:100vw}

/* ════════════════════════════════════════
   TOOLBAR
════════════════════════════════════════ */
#toolbar{
  position:fixed;top:0;left:0;right:0;height:50px;
  background:linear-gradient(180deg,#2e1800 0%,#1a0d00 100%);
  border-bottom:2px solid #6b3a10;
  display:flex;align-items:center;gap:6px;padding:0 14px;
  z-index:9000;box-shadow:0 3px 15px rgba(0,0,0,.85);
  user-select:none;
}
#toolbar .brand{
  color:#e0a030;font-size:.95rem;font-weight:700;letter-spacing:1.5px;
  margin-right:8px;text-shadow:0 0 12px rgba(224,160,48,.5);white-space:nowrap;
}
.tbtn{
  display:flex;align-items:center;gap:4px;
  background:#2e1800;border:1px solid #6b3a10;color:#d4943a;
  padding:3px 10px;border-radius:4px;cursor:pointer;font-size:.78rem;
  transition:all .15s;white-space:nowrap;line-height:1.6;
}
.tbtn:hover{background:#4a2600;border-color:#d4943a;color:#ffe090}
.tbtn.on{background:#7a1500;border-color:#ff4422;color:#fff;box-shadow:0 0 8px rgba(255,60,0,.4)}
.tbtn i{font-size:.88rem}
.tsep{width:1px;height:28px;background:#6b3a10;flex-shrink:0;margin:0 2px}
.tsel{background:#2e1800;border:1px solid #6b3a10;color:#d4943a;padding:2px 6px;border-radius:4px;font-size:.76rem;cursor:pointer}
.tsel:focus{outline:none;border-color:#d4943a}
input[type=color]#str-color{width:28px;height:26px;border:1px solid #6b3a10;border-radius:4px;cursor:pointer;padding:1px 2px;background:#2e1800}

/* ════════════════════════════════════════
   BOARD WRAP & BOARD
════════════════════════════════════════ */
#wrap{position:fixed;top:50px;left:0;right:0;bottom:0;overflow:hidden;cursor:grab}
#board{
  position:absolute;width:5000px;height:4000px;top:0;left:0;min-width:5000px;min-height:4000px;
  transform-origin:0 0;
  /* Cork wood background */
  background-color:#6b4226;
  background-image:
    repeating-linear-gradient(0deg,  transparent,transparent 3px,rgba(0,0,0,.04) 3px,rgba(0,0,0,.04) 4px),
    repeating-linear-gradient(90deg, transparent,transparent 3px,rgba(0,0,0,.03) 3px,rgba(0,0,0,.03) 4px),
    radial-gradient(ellipse at 20% 30%,#7a4f2e 0%,transparent 60%),
    radial-gradient(ellipse at 75% 70%,#5a3318 0%,transparent 55%),
    radial-gradient(ellipse at 50% 50%,#614030 0%,transparent 80%);
}
#board::after{
  content:'';position:absolute;inset:0;pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='.4'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)' opacity='.12'/%3E%3C/svg%3E");
  opacity:.7;
}

/* ════════════════════════════════════════
   CANVAS
════════════════════════════════════════ */
#cv{position:absolute;top:0;left:0;width:5000px;height:4000px;pointer-events:none;z-index:2;min-width:5000px;min-height:4000px}
#cv.sm{pointer-events:all;cursor:crosshair}

/* ════════════════════════════════════════
   BOARD ITEMS
════════════════════════════════════════ */
.bitem{position:absolute;z-index:10;cursor:grab;user-select:none}
.bitem.dragging{cursor:grabbing;z-index:500!important}
.bitem.pinned{cursor:default}
.bitem.sel>.inner{outline:2px dashed #ff5500!important;outline-offset:3px}

/* ── PIN THUMB TACK ── */
.pin-head{
  position:absolute;top:-13px;left:50%;transform:translateX(-50%);
  width:14px;height:14px;border-radius:50%;z-index:6;
  box-shadow:inset 0 -2px 3px rgba(0,0,0,.5),0 2px 6px rgba(0,0,0,.7);
  pointer-events:none;
}
.pin-head::after{
  content:'';position:absolute;top:11px;left:6px;
  width:2px;height:10px;background:rgba(80,40,0,.7);
  border-radius:0 0 2px 2px;transform:rotate(3deg);
}

/* ── PHOTO ── */
.photo .inner{
  background:#f8f4ed;
  padding:7px 7px 28px;
  box-shadow:3px 4px 12px rgba(0,0,0,.75),inset 0 0 0 1px rgba(0,0,0,.08);
  position:relative;
}
.photo img{display:block;width:190px;height:148px;object-fit:cover;filter:contrast(1.1) saturate(.8)}
.photo .plabel{
  position:absolute;bottom:5px;left:0;right:0;
  font-family:'Courier New',monospace;font-size:.67rem;color:#444;
  text-align:center;padding:0 6px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;
}

/* ── STICKY NOTE ── */
.note .inner{
  width:168px;min-height:130px;padding:28px 11px 12px;
  position:relative;overflow:hidden;
  background:linear-gradient(160deg,#ffe86a 0%,#ffd400 100%);
  box-shadow:3px 4px 12px rgba(0,0,0,.65),inset 0 0 0 1px rgba(0,0,0,.06);
}
.note .inner::before{
  content:'';position:absolute;top:0;left:0;right:0;height:24px;
  background:linear-gradient(180deg,#ffc000,#ffca00);
  border-bottom:1px solid rgba(0,0,0,.18);
}
/* ruled lines */
.note .inner::after{
  content:'';position:absolute;left:11px;right:11px;
  top:44px;bottom:10px;
  background:repeating-linear-gradient(
    180deg,transparent,transparent 17px,rgba(0,0,100,.08) 17px,rgba(0,0,100,.08) 18px
  );
  pointer-events:none;
}
.note .ntxt{
  font-family:'Courier New',monospace;font-size:.8rem;color:#2a1200;
  line-height:1.5;word-break:break-word;min-height:80px;
  outline:none;position:relative;z-index:1;
  background:transparent;
}

/* ── DOCUMENT / NEWSPAPER ── */
.doc .inner{
  width:210px;background:#f2ead8;
  padding:10px;
  box-shadow:3px 4px 12px rgba(0,0,0,.7);
  border:1px solid #bbb;
  font-family:'Times New Roman',serif;position:relative;
}
.doc .dtitle{
  font-size:.9rem;font-weight:700;border-bottom:2px solid #333;
  padding-bottom:4px;margin-bottom:5px;text-align:center;outline:none;
}
.doc .dbody{
  font-size:.63rem;line-height:1.55;color:#222;
  outline:none;
}
.doc .inner::before{
  content:'';position:absolute;top:0;left:0;right:0;height:5px;
  background:repeating-linear-gradient(90deg,#333 0,#333 4px,transparent 4px,transparent 8px);
}

/* ── ITEM CONTROLS (hover bar) ── */
.ictl{
  display:none;position:absolute;top:-34px;left:50%;transform:translateX(-50%);
  background:rgba(10,5,0,.9);border:1px solid #6b3a10;border-radius:5px;
  padding:2px 5px;gap:1px;white-space:nowrap;z-index:200;
}
.bitem:hover .ictl,.bitem.sel .ictl{display:flex}
.ictl button{
  background:none;border:none;color:#d4943a;cursor:pointer;
  font-size:.78rem;padding:2px 5px;border-radius:3px;line-height:1.4;
}
.ictl button:hover{background:rgba(212,148,58,.18);color:#ffe090}
.ictl button.danger:hover{background:rgba(255,60,60,.18);color:#ff8080}

/* ── ROTATE HANDLE ── */
.rhandle{
  display:none;position:absolute;bottom:-22px;left:50%;transform:translateX(-50%);
  width:14px;height:14px;background:#d4943a;border-radius:50%;
  cursor:alias;z-index:201;box-shadow:0 0 4px rgba(0,0,0,.6);
}
.bitem:hover .rhandle,.bitem.sel .rhandle{display:block}

/* ── RESIZE HANDLE ── */
.szhandle{
  display:none;position:absolute;bottom:-9px;right:-9px;
  width:17px;height:17px;background:#3ab4d4;border-radius:4px;
  cursor:se-resize;z-index:202;
  box-shadow:0 0 5px rgba(0,0,0,.7);
  border:2px solid #1a6b8a;font-size:10px;color:#fff;
  line-height:13px;text-align:center;
}
.bitem:hover .szhandle,.bitem.sel .szhandle{display:block}

/* ── SIDE RESIZE HANDLES ── */
.srh{display:none;position:absolute;background:#3ab4d4;z-index:203;border:1px solid #1a6b8a;border-radius:4px;opacity:.85;}
.srh-l,.srh-r{width:8px;height:36px;top:50%;margin-top:-18px;cursor:ew-resize;}
.srh-t,.srh-b{height:8px;width:36px;left:50%;margin-left:-18px;cursor:ns-resize;}
.srh-l{left:-9px}.srh-r{right:-9px}.srh-t{top:-9px}.srh-b{bottom:-9px}
.srh-tl,.srh-tr,.srh-bl{width:13px;height:13px;border-radius:3px;}
.srh-tl{top:-8px;left:-8px;cursor:nwse-resize}
.srh-tr{top:-8px;right:-8px;cursor:nesw-resize}
.srh-bl{bottom:-8px;left:-8px;cursor:nesw-resize}
.bitem:hover .srh,.bitem.sel .srh{display:block}

/* ── CONNECTION POINTS ── */
.cp{
  position:absolute;width:12px;height:12px;background:rgba(220,40,40,.8);
  border-radius:50%;transform:translate(-50%,-50%);
  display:none;cursor:crosshair;z-index:60;
  box-shadow:0 0 8px rgba(255,0,0,.6);pointer-events:all;
}
#board.sm .bitem:hover .cp{display:block}
.cp.t{top:0%;left:50%}
.cp.b{top:100%;left:50%}
.cp.l{top:50%;left:0%}
.cp.r{top:50%;left:100%}
.cp.c{top:50%;left:50%}

/* ── STRING LABEL (post-it on string) ── */
.slabel{
  position:absolute;background:#ffe55a;color:#2a1000;
  font-family:'Courier New',monospace;font-size:.72rem;
  padding:3px 7px 3px;border-radius:2px;cursor:pointer;
  box-shadow:2px 2px 5px rgba(0,0,0,.55);
  transform:translate(-50%,-50%) rotate(var(--r,-2deg));
  z-index:30;max-width:130px;text-align:center;
  border:1px solid rgba(0,0,0,.15);line-height:1.3;
  white-space:pre-wrap;word-break:break-word;
  transition:background .15s;
}
.slabel::before{
  content:'';position:absolute;top:0;left:0;right:0;height:6px;
  background:rgba(255,180,0,.6);border-radius:2px 2px 0 0;
}
.slabel:hover{background:#ffd600}
.slabel.editing{background:#fff;cursor:text}

/* ── SLABEL EDITOR PANEL ── */
#slabel-editor{
  position:fixed;z-index:99999;background:#2a1800;border:2px solid #c08030;
  border-radius:8px;padding:10px 14px 12px;box-shadow:0 6px 24px rgba(0,0,0,.7);
  color:#f5d990;font-size:.78rem;display:none;min-width:240px;
  font-family:'Courier New',monospace;
}
#slabel-editor .se-title{font-weight:bold;color:#ffd600;margin-bottom:8px;font-size:.82rem;
  border-bottom:1px solid #6b3a10;padding-bottom:4px;padding-right:18px;}
#slabel-editor .se-row{display:flex;align-items:center;gap:6px;margin-bottom:6px;flex-wrap:wrap;}
#slabel-editor label{color:#c08030;font-size:.72rem;min-width:72px;}
#slabel-editor button.se-btn{background:#6b3a10;border:1px solid #c08030;color:#f5d990;
  border-radius:4px;padding:2px 8px;cursor:pointer;font-size:.8rem;line-height:1.4;}
#slabel-editor button.se-btn:hover{background:#c08030;color:#2a1000;}
#slabel-editor input[type=color]{width:34px;height:24px;border:none;cursor:pointer;border-radius:3px;padding:0;}
#slabel-editor input[type=range]{flex:1;min-width:80px;accent-color:#c08030;}
#slabel-editor .se-val{color:#ffd600;font-size:.72rem;min-width:32px;text-align:right;}
#slabel-editor .se-close{position:absolute;top:6px;right:8px;cursor:pointer;color:#c08030;font-size:1rem;}
#slabel-editor .se-close:hover{color:#ffd600;}

/* ════════════════════════════════════════
   HUD
════════════════════════════════════════ */
#hud-zoom{
  position:fixed;bottom:12px;right:14px;
  background:rgba(0,0,0,.75);color:#d4943a;
  padding:4px 11px;border-radius:5px;font-size:.76rem;
  border:1px solid #6b3a10;z-index:9000;pointer-events:none;
}
#hud-ctrlsave{
  position:fixed;top:12px;right:14px;
  background:rgba(0,0,0,.72);color:#c08030;
  padding:5px 12px;border-radius:6px;font-size:.72rem;
  border:1px solid #6b3a10;z-index:9000;pointer-events:none;
  display:flex;align-items:center;gap:6px;
  box-shadow:0 2px 8px rgba(0,0,0,.5);
  font-family:'Courier New',monospace;letter-spacing:.02em;
}
#hud-ctrlsave kbd{
  background:#3a1800;border:1px solid #c08030;color:#ffd600;
  border-radius:3px;padding:1px 5px;font-size:.7rem;
  font-family:'Courier New',monospace;
}
#hud-ctrlsave.saved{color:#5ddf7a;border-color:#2a6b10;}
#hud-mode{
  position:fixed;bottom:12px;left:50%;transform:translateX(-50%);
  background:rgba(180,10,0,.88);color:#fff;padding:5px 18px;
  border-radius:20px;font-size:.8rem;z-index:9000;
  display:none;border:1px solid #ff4422;
  box-shadow:0 0 18px rgba(255,0,0,.4);pointer-events:none;
}

/* ════════════════════════════════════════
   MODALS
════════════════════════════════════════ */
.mdark .modal-content{background:#160900;border:1px solid #6b3a10;color:#d4943a}
.mdark .modal-header{border-bottom:1px solid #6b3a10;padding:.75rem 1rem}
.mdark .modal-footer{border-top:1px solid #6b3a10}
.mdark .btn-close{filter:invert(1) sepia(1) saturate(3) hue-rotate(20deg)}
.mdark .form-label{color:#c08030;font-size:.82rem}
.mdark .form-control,.mdark .form-select{
  background:#200e00;border-color:#6b3a10;color:#f0d090;font-size:.85rem;
}
.mdark .form-control:focus{background:#2e1400;border-color:#d4943a;color:#fff;box-shadow:none}
#upzone{
  border:2px dashed #6b3a10;border-radius:8px;padding:22px 10px;
  text-align:center;cursor:pointer;color:#d4943a;transition:all .2s;
}
#upzone:hover,#upzone.dv{background:rgba(107,58,16,.22);border-color:#d4943a}

/* context menu */
#ctx-menu{
  position:fixed;background:#1e0c00;border:1px solid #6b3a10;border-radius:6px;
  padding:5px 0;z-index:9999;display:none;min-width:150px;
  box-shadow:3px 3px 12px rgba(0,0,0,.8);
}
#ctx-menu .cm-item{
  padding:6px 16px;cursor:pointer;color:#d4943a;font-size:.82rem;
  display:flex;align-items:center;gap:8px;
}
#ctx-menu .cm-item:hover{background:rgba(212,148,58,.15);color:#ffe090}
#ctx-menu .cm-sep{border-top:1px solid #4a2200;margin:4px 0}
/* ── TOAST AUTOSAVE ── */
#toast-save{
  position:fixed;bottom:48px;right:14px;
  background:rgba(0,160,60,.92);color:#fff;
  padding:6px 16px;border-radius:20px;font-size:.8rem;
  z-index:9999;pointer-events:none;
  opacity:0;transition:opacity .3s;
  border:1px solid rgba(0,255,80,.3);
  box-shadow:0 2px 10px rgba(0,0,0,.5);
}
#toast-save.show{opacity:1}
</style>
</head>
<body>

<!-- ═══════════════ TOOLBAR ═══════════════ -->
<div id="toolbar">
  <span class="brand">🔍 QUADRO INVESTIGADOR</span>
  <div class="tsep"></div>
  <button class="tbtn" onclick="openAddPhoto()"><i class="bi bi-image-fill"></i> Foto</button>
  <button class="tbtn" onclick="addNote()"><i class="bi bi-sticky-fill"></i> Nota</button>
  <button class="tbtn" onclick="addDoc()"><i class="bi bi-newspaper"></i> Doc</button>
  <div class="tsep"></div>
  <button class="tbtn" id="btn-str" onclick="toggleStrMode()"><i class="bi bi-share-fill"></i> Fio</button>
  <input type="color" id="str-color" value="#c00000" title="Cor do fio">
  <select class="tsel" id="str-w" title="Espessura do fio">
    <option value="1.5">Fino</option>
    <option value="2.5" selected>Normal</option>
    <option value="4">Grosso</option>
  </select>
  <div class="tsep"></div>
  <button class="tbtn" onclick="delSelected()"><i class="bi bi-trash3"></i> Del</button>
  <button class="tbtn" onclick="clearBoard()" style="color:#ff9090"><i class="bi bi-eraser-fill"></i> Limpar</button>
  <div class="tsep"></div>
  <button class="tbtn" onclick="saveBoard()"><i class="bi bi-floppy2-fill"></i> Salvar</button>
  <button class="tbtn" onclick="loadBoardFile()"><i class="bi bi-folder2-open"></i> Abrir</button>
  <div class="tsep"></div>
  <button class="tbtn" onclick="doZoom(0.12)"><i class="bi bi-zoom-in"></i></button>
  <button class="tbtn" onclick="doZoom(-0.12)"><i class="bi bi-zoom-out"></i></button>
  <button class="tbtn" onclick="resetView()"><i class="bi bi-arrows-fullscreen"></i></button>
</div>

<!-- ═══════════════ BOARD ═══════════════ -->
<div id="wrap">
  <div id="board">
    <canvas id="cv" width="5000" height="4000"></canvas>
  </div>
</div>

<!-- HUD -->
<div id="hud-zoom">Zoom: 100%</div>
<div id="hud-ctrlsave"><kbd>Ctrl</kbd>+<kbd>S</kbd> Salvar progresso</div>
<div id="toast-save">✓ Progresso salvo!</div>
<div id="hud-mode">✂ MODO FIO — Clique em dois itens para conectar &nbsp;[ESC cancela]</div>

<!-- Context Menu -->
<div id="ctx-menu">
  <div class="cm-item" id="cm-photo" onclick="openAddPhoto();closeCtx()"><i class="bi bi-image-fill"></i> Adicionar Foto</div>
  <div class="cm-item" id="cm-note"  onclick="addNoteAt();closeCtx()"><i class="bi bi-sticky-fill"></i> Adicionar Nota</div>
  <div class="cm-item" id="cm-doc"   onclick="addDocAt();closeCtx()"><i class="bi bi-newspaper"></i> Adicionar Doc</div>
  <div class="cm-sep"></div>
  <div class="cm-item" onclick="toggleStrMode();closeCtx()"><i class="bi bi-share-fill"></i> Modo Fio</div>
  <div class="cm-sep"></div>
  <div class="cm-item" onclick="delSelected();closeCtx()" style="color:#ff8080"><i class="bi bi-trash3"></i> Excluir selecionado</div>
</div>

<!-- ═══════════════ MODAL FOTO ═══════════════ -->
<div class="modal fade mdark" id="mPhoto" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-image-fill me-2"></i>Adicionar Foto</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="upzone"
          onclick="document.getElementById('fInput').click()"
          ondragover="event.preventDefault();this.classList.add('dv')"
          ondragleave="this.classList.remove('dv')"
          ondrop="dropFile(event)">
          <i class="bi bi-cloud-upload fs-1 d-block mb-2"></i>
          Clique ou <strong>arraste</strong> uma imagem aqui<br>
          <small style="color:#8B5A2B">JPG · PNG · GIF · WEBP</small>
        </div>
        <input type="file" id="fInput" accept="image/*" style="display:none" onchange="pickFile(event)">
        <div class="mt-3">
          <label class="form-label">Ou URL direta:</label>
          <input type="text" class="form-control" id="pUrl" placeholder="https://...">
        </div>
        <div class="mt-2">
          <label class="form-label">Etiqueta:</label>
          <input type="text" class="form-control" id="pLbl" placeholder="Ex: Suspeito N.3, Local do crime…">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
        <button class="btn btn-warning btn-sm" onclick="confirmPhoto()"><i class="bi bi-plus-lg me-1"></i>Adicionar</button>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════ MODAL COMMENT STRING ═══════════════ -->
<div class="modal fade mdark" id="mStr" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-chat-right-quote-fill me-2"></i>Comentário no Fio</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label">Texto (opcional — deixe em branco para sem comentário):</label>
        <textarea class="form-control" id="strCmt" rows="3" placeholder="Ex: Encontrados juntos às 22h…"></textarea>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal" onclick="cancelStr()">Cancelar</button>
        <button class="btn btn-warning btn-sm" onclick="confirmStr()"><i class="bi bi-check-lg me-1"></i>Confirmar</button>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════ MODAL EDIT LABEL ═══════════════ -->
<div class="modal fade mdark" id="mLbl" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-pencil-fill me-2"></i>Editar Etiqueta</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="text" class="form-control" id="lblVal" placeholder="Texto da etiqueta…">
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
        <button class="btn btn-warning btn-sm" onclick="confirmLbl()">Salvar</button>
      </div>
    </div>
  </div>
</div>

<!-- ═══ SLABEL EDITOR PANEL ═══ -->
<div id="slabel-editor">
  <span class="se-close" onclick="closeSLabelEditor()">✕</span>
  <div class="se-title">🏷️ Editar Etiqueta</div>
  <div class="se-row">
    <label>Fonte:</label>
    <button class="se-btn" onclick="seFontSize(-1)">A−</button>
    <span class="se-val" id="se-fs-val">11</span>
    <button class="se-btn" onclick="seFontSize(1)">A+</button>
  </div>
  <div class="se-row">
    <label>Girar:</label>
    <button class="se-btn" onclick="seRotate(-15)">↺ −15°</button>
    <span class="se-val" id="se-rot-val">0°</span>
    <button class="se-btn" onclick="seRotate(15)">↻ +15°</button>
  </div>
  <div class="se-row">
    <label>Largura:</label>
    <button class="se-btn" onclick="seWidth(-20)">−</button>
    <span class="se-val" id="se-w-val">130</span>
    <button class="se-btn" onclick="seWidth(20)">+</button>
  </div>
  <div class="se-row">
    <label>Cor texto:</label>
    <input type="color" id="se-color" value="#2a1000" oninput="seTextColor(this.value)">
  </div>
  <div class="se-row">
    <label>Cor fundo:</label>
    <input type="color" id="se-bg" value="#ffe55a" oninput="seBgColor(this.value)">
  </div>
  <div class="se-row" style="margin-top:4px;border-top:1px solid #6b3a10;padding-top:6px;">
    <button class="se-btn" style="width:100%;background:#3a1000" onclick="seReset()">↺ Resetar</button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ════════════════════════════════════════════════════
//  GLOBALS
// ════════════════════════════════════════════════════
const board = document.getElementById('board');
const wrap  = document.getElementById('wrap');
const cv    = document.getElementById('cv');
const ctx   = cv.getContext('2d');

let zoom=1, panX=0, panY=0;
let isPan=false, panS={x:0,y:0}, spaceDown=false;

let strMode=false, strDrawing=false, strFrom=null, strTemp=null;
let pendStr=null; // {from,to,color,width}

let items=[];   // item objects
let strings=[]; // string objects
let idN=1;
let selId=null;

let rotItem=null, rotA0=0, rotI0=0;
let ctxMenuPos={x:0,y:0}; // board coords of last right-click
let lblTarget=null;

// ════════════════════════════════════════════════════
//  TRANSFORM
// ════════════════════════════════════════════════════
function applyT(){
  board.style.transform=`translate(${panX}px,${panY}px) scale(${zoom})`;
  document.getElementById('hud-zoom').textContent=`Zoom: ${Math.round(zoom*100)}%`;
}
function doZoom(d){zoom=Math.min(Math.max(zoom+d,.15),4);applyT()}
function resetView(){zoom=1;panX=0;panY=0;applyT()}

wrap.addEventListener('wheel',e=>{
  e.preventDefault();
  const d=e.deltaY>0?-.09:.09;
  zoom=Math.min(Math.max(zoom+d,.15),4);applyT();
},{passive:false});

// PAN
document.addEventListener('keydown',e=>{
  if(e.code==='Space'&&document.activeElement===document.body){spaceDown=true;wrap.style.cursor='grab';e.preventDefault();}
  if((e.code==='Delete'||e.code==='Backspace')&&document.activeElement===document.body) delSelected();
  if(e.code==='Escape'){if(strMode)toggleStrMode();desel()}
});
document.addEventListener('keyup',e=>{if(e.code==='Space'){spaceDown=false;if(!isPan)wrap.style.cursor='grab';}});

wrap.addEventListener('mousedown',e=>{
  // Pan com botão do meio, espaço+clique, ou clique direto no fundo vazio
  const onEmpty = e.target===wrap||e.target===board||e.target===cv;
  if(e.button===1||(e.button===0&&spaceDown)||(e.button===0&&onEmpty&&!strMode)){
    isPan=true;panS={x:e.clientX-panX,y:e.clientY-panY};
    wrap.style.cursor='grabbing';
    e.preventDefault();
  }
});
document.addEventListener('mousemove',e=>{
  if(isPan){panX=e.clientX-panS.x;panY=e.clientY-panS.y;applyT();wrap.style.cursor='grabbing';}
  if(strDrawing&&strTemp){strTemp.end=bpos(e);redraw()}
  if(rotItem){
    const r=rotItem.el.getBoundingClientRect();
    const cx2=r.left+r.width/2, cy2=r.top+r.height/2;
    const a=Math.atan2(e.clientY-cy2,e.clientX-cx2)*180/Math.PI;
    rotItem.rot=rotI0+(a-rotA0);
    applyItemTransform(rotItem);
  }
  if(srItem){
    const dx=(e.clientX-srSX)/zoom,dy=(e.clientY-srSY)/zoom;const d=srDir;
    if(d==='r'||d==='tr'){srItem.innerW=Math.max(srW0+dx,80);}
    if(d==='l'||d==='tl'||d==='bl'){const nw=Math.max(srW0-dx,80);const ddx=srW0-nw;srItem.innerW=nw;srItem.x=srX0+ddx;srItem.el.style.left=srItem.x+'px';}
    if(d==='b'||d==='bl'){srItem.innerH=Math.max(srH0+dy,60);}
    if(d==='t'||d==='tl'||d==='tr'){const nh=Math.max(srH0-dy,60);const ddy=srH0-nh;srItem.innerH=nh;srItem.y=srY0+ddy;srItem.el.style.top=srItem.y+'px';}
    applyInnerSize(srItem);redraw();
  }
});
document.addEventListener('mouseup',e=>{
  if(isPan&&e.button!==2){isPan=false;wrap.style.cursor=spaceDown?'grabbing':'grab';}
  if(rotItem)rotItem=null;
  if(srItem)srItem=null;
});

// Right-click context menu
wrap.addEventListener('contextmenu',e=>{
  e.preventDefault();
  ctxMenuPos=bpos(e);
  const m=document.getElementById('ctx-menu');
  m.style.left=e.clientX+'px';m.style.top=e.clientY+'px';m.style.display='block';
});
document.addEventListener('click',()=>closeCtx());
function closeCtx(){document.getElementById('ctx-menu').style.display='none'}

// ════════════════════════════════════════════════════
//  COORDINATE HELPER
// ════════════════════════════════════════════════════
function bpos(e){
  const r=wrap.getBoundingClientRect();
  return{x:(e.clientX-r.left-panX)/zoom,y:(e.clientY-r.top-panY)/zoom};
}
function iCenter(item){
  const el=item.el;
  return{x:item.x+el.offsetWidth/2,y:item.y+el.offsetHeight/2};
}

// ════════════════════════════════════════════════════
//  CREATE ITEM
// ════════════════════════════════════════════════════
function mkItem(type,x,y,data){
  const id='i'+(idN++);
  const rot=(Math.random()*10-5);
  const el=document.createElement('div');
  el.className=`bitem ${type}`;el.id=id;
  el.style.cssText=`left:${x}px;top:${y}px;transform:rotate(${rot}deg)`;

  // Connection points
  ['t','b','l','r','c'].forEach(p=>{
    const cp=document.createElement('div');
    cp.className=`cp ${p}`;
    cp.addEventListener('mousedown',e=>{if(strMode){e.stopPropagation();startStr(id,e)}});
    el.appendChild(cp);
  });

  // Controls bar
  el.insertAdjacentHTML('beforeend',`
    <div class="ictl">
      <button title="Pino fixar/soltar" onclick="togglePin('${id}')"><i class="bi bi-pin-angle-fill"></i></button>
      <button title="Girar +" onclick="rotateBy('${id}',15)"><i class="bi bi-arrow-clockwise"></i></button>
      <button title="Girar -" onclick="rotateBy('${id}',-15)"><i class="bi bi-arrow-counterclockwise"></i></button>
      <button title="Aumentar tamanho" onclick="scaleItem('${id}',0.12)"><i class="bi bi-plus-square-fill"></i></button>
      <button title="Diminuir tamanho" onclick="scaleItem('${id}',-0.12)"><i class="bi bi-dash-square-fill"></i></button>
      ${(type==='note'||type==='doc')?`<button title="Aumentar fonte" onclick="changeFontSize('${id}',2)"><i class="bi bi-fonts"></i>+</button><button title="Diminuir fonte" onclick="changeFontSize('${id}',-2)"><i class="bi bi-fonts"></i>-</button><input type="color" value="#2a1200" onchange="changeTextColor('${id}',this.value)" title="Cor do texto" style="width:22px;height:22px;border:none;border-radius:3px;cursor:pointer;padding:1px;background:#2e1800;vertical-align:middle">`:``}
      ${type==='photo'?`<button title="Editar etiqueta" onclick="openLbl('${id}')"><i class="bi bi-tag-fill"></i></button>`:''}
      <button title="Clonar" onclick="cloneItem('${id}')"><i class="bi bi-copy"></i></button>
      <button class="danger" title="Excluir" onclick="removeItem('${id}')"><i class="bi bi-trash3-fill"></i></button>
    </div>
    <div class="rhandle" id="rh_${id}"></div>
    <div class="szhandle" id="sh_${id}">⤡</div>
    <div class="srh srh-l" id="sl_${id}"></div>
    <div class="srh srh-r" id="sr_${id}"></div>
    <div class="srh srh-t" id="st_${id}"></div>
    <div class="srh srh-b" id="sb_${id}"></div>
    <div class="srh srh-tl" id="stl_${id}"></div>
    <div class="srh srh-tr" id="str_${id}"></div>
    <div class="srh srh-bl" id="sbl_${id}"></div>
  `);

  // Pin head (thumb tack)
  const ph=document.createElement('div');
  ph.className='pin-head';
  ph.style.background=['#c33','#339','#393','#c80','#833'][Math.floor(Math.random()*5)];
  el.appendChild(ph);

  // Inner
  const inner=document.createElement('div');
  inner.className='inner';

  if(type==='photo'){
    const img=document.createElement('img');img.src=data.url;img.draggable=false;
    const lbl=document.createElement('div');lbl.className='plabel';lbl.textContent=data.label||'';
    inner.appendChild(img);inner.appendChild(lbl);
  }else if(type==='note'){
    const t=document.createElement('div');t.className='ntxt';t.contentEditable='true';
    t.textContent=data.text||'Clique para editar...';
    t.addEventListener('mousedown',e=>e.stopPropagation());
    inner.appendChild(t);
  }else if(type==='doc'){
    const ti=document.createElement('div');ti.className='dtitle';ti.contentEditable='true';ti.textContent=data.title||'RELATÓRIO';
    const bd=document.createElement('div');bd.className='dbody';bd.contentEditable='true';bd.textContent=data.body||'Clique para editar...';
    [ti,bd].forEach(n=>n.addEventListener('mousedown',e=>e.stopPropagation()));
    inner.appendChild(ti);inner.appendChild(bd);
  }
  el.appendChild(inner);

  // Rotate handle
  el.querySelector('#rh_'+id).addEventListener('mousedown',e=>beginRot(id,e));
  // Resize handle (scale)
  el.querySelector('#sh_'+id).addEventListener('mousedown',e=>beginResize(id,e));
  // Side resize handles
  ['l','r','t','b','tl','tr','bl'].forEach(d=>{
    const h=el.querySelector('#s'+d+'_'+id);
    if(h) h.addEventListener('mousedown',e=>beginSideResize(id,d,e));
  });

  // Select
  el.addEventListener('mousedown',e=>{
    if(e.button!==0||strMode||spaceDown)return;
    sel(id);
  });

  makeDrag(el,id);
  board.appendChild(el);

  const obj={id,el,x,y,rot,type,pinned:false,data,itemScale:1,fontSize:null};
  items.push(obj);
  autoExpand();
  return obj;
}

// ════════════════════════════════════════════════════
//  DRAG
// ════════════════════════════════════════════════════
function makeDrag(el,id){
  let dragging=false,ox=0,oy=0;
  el.addEventListener('mousedown',e=>{
    if(e.button!==0||strMode||spaceDown)return;
    const item=items.find(i=>i.id===id);
    if(item?.pinned)return;
    dragging=true;
    const p=bpos(e);ox=p.x-item.x;oy=p.y-item.y;
    el.classList.add('dragging');e.stopPropagation();
  });
  document.addEventListener('mousemove',e=>{
    if(!dragging)return;
    const item=items.find(i=>i.id===id);if(!item)return;
    const p=bpos(e);item.x=p.x-ox;item.y=p.y-oy;
    el.style.left=item.x+'px';el.style.top=item.y+'px';
    redraw();autoExpand();
  });
  document.addEventListener('mouseup',()=>{if(dragging){dragging=false;el.classList.remove('dragging')}});
}

// ════════════════════════════════════════════════════
//  ROTATE
// ════════════════════════════════════════════════════
function beginRot(id,e){
  e.stopPropagation();e.preventDefault();
  const item=items.find(i=>i.id===id);
  const r=item.el.getBoundingClientRect();
  rotA0=Math.atan2(e.clientY-(r.top+r.height/2),e.clientX-(r.left+r.width/2))*180/Math.PI;
  rotI0=item.rot||0;rotItem=item;
}
function applyItemTransform(item){
  item.el.style.transform=`rotate(${item.rot||0}deg) scale(${item.itemScale||1})`;
}
function rotateBy(id,d){
  const item=items.find(i=>i.id===id);if(!item)return;
  item.rot=(item.rot||0)+d;
  applyItemTransform(item);
}

// ════════════════════════════════════════════════════
//  SCALE / FONT / COLOR / RESIZE
// ════════════════════════════════════════════════════
function scaleItem(id,delta){
  const item=items.find(i=>i.id===id);if(!item)return;
  item.itemScale=Math.min(Math.max((item.itemScale||1)+delta,0.3),4);
  applyItemTransform(item);
  redraw();
}

function changeFontSize(id,delta){
  const item=items.find(i=>i.id===id);if(!item)return;
  if(item.type==='note'){
    const t=item.el.querySelector('.ntxt');if(!t)return;
    const cur=parseFloat(getComputedStyle(t).fontSize)||12.8;
    const nw=Math.min(Math.max(cur+delta,6),72);
    t.style.fontSize=nw+'px';
    item.fontSize=nw;
  }else if(item.type==='doc'){
    const ti=item.el.querySelector('.dtitle');
    const bd=item.el.querySelector('.dbody');
    const cur=parseFloat(getComputedStyle(bd).fontSize)||10;
    const nw=Math.min(Math.max(cur+delta,5),60);
    if(bd)bd.style.fontSize=nw+'px';
    if(ti)ti.style.fontSize=Math.min(Math.max(nw*1.4,7),72)+'px';
    item.fontSize=nw;
  }
}

function changeTextColor(id,color){
  const item=items.find(i=>i.id===id);if(!item)return;
  if(item.type==='note'){
    const t=item.el.querySelector('.ntxt');if(t)t.style.color=color;
  }else if(item.type==='doc'){
    const ti=item.el.querySelector('.dtitle');
    const bd=item.el.querySelector('.dbody');
    if(ti)ti.style.color=color;
    if(bd)bd.style.color=color;
  }
  item.textColor=color;
}

// ── RESIZE DRAG ──
let resizeItem=null,resizeSX=0,resizeSY=0,resizeS0=1;
let srItem=null,srDir='',srSX=0,srSY=0,srW0=0,srH0=0,srX0=0,srY0=0;
function beginResize(id,e){
  e.stopPropagation();e.preventDefault();
  const item=items.find(i=>i.id===id);if(!item)return;
  resizeItem=item;
  resizeSX=e.clientX;resizeSY=e.clientY;
  resizeS0=item.itemScale||1;
}
document.addEventListener('mousemove',e=>{
  if(!resizeItem)return;
  const dx=e.clientX-resizeSX;
  const dy=e.clientY-resizeSY;
  const dist=Math.sqrt(dx*dx+dy*dy)*(dx+dy>0?1:-1);
  resizeItem.itemScale=Math.min(Math.max(resizeS0+dist/200,0.3),4);
  applyItemTransform(resizeItem);
  // Also scale fonts proportionally
  if(resizeItem.type==='note'||resizeItem.type==='doc'){
    changeFontSizeAbsolute(resizeItem,resizeItem.itemScale);
  }
  redraw();
});
document.addEventListener('mouseup',()=>{if(resizeItem)resizeItem=null;});

function getInnerSize(item){const inner=item.el.querySelector('.inner');return{w:inner.offsetWidth,h:inner.offsetHeight};}
function applyInnerSize(item){
  const inner=item.el.querySelector('.inner');
  if(item.innerW) inner.style.width=item.innerW+'px';
  if(item.innerH) inner.style.minHeight=item.innerH+'px';
  if(item.type==='photo'){
    const img=inner.querySelector('img');
    if(img&&item.innerW) img.style.width=Math.max(item.innerW-14,40)+'px';
    if(img&&item.innerH) img.style.height=Math.max(item.innerH-33,30)+'px';
  }

}
function beginSideResize(id,dir,e){
  e.stopPropagation();e.preventDefault();
  const item=items.find(i=>i.id===id);if(!item)return;
  srItem=item;srDir=dir;srSX=e.clientX;srSY=e.clientY;
  const sz=getInnerSize(item);
  srW0=item.innerW||sz.w;srH0=item.innerH||sz.h;
  srX0=item.x;srY0=item.y;
}
function changeFontSizeAbsolute(item,scale){
  if(item.type==='note'){
    const t=item.el.querySelector('.ntxt');if(!t)return;
    const base=item.fontSizeBase||12.8;
    t.style.fontSize=Math.min(Math.max(base*scale,6),72)+'px';
  }else if(item.type==='doc'){
    const ti=item.el.querySelector('.dtitle');
    const bd=item.el.querySelector('.dbody');
    const base=item.fontSizeBase||10;
    const nw=Math.min(Math.max(base*scale,5),60);
    if(bd)bd.style.fontSize=nw+'px';
    if(ti)ti.style.fontSize=Math.min(Math.max(nw*1.4,7),72)+'px';
  }
}

// ════════════════════════════════════════════════════
//  SELECT
// ════════════════════════════════════════════════════
function sel(id){desel();selId=id;items.find(i=>i.id===id)?.el.classList.add('sel')}
function desel(){if(selId){items.find(i=>i.id===selId)?.el.classList.remove('sel')}selId=null}
wrap.addEventListener('click',e=>{if(e.target===wrap||e.target===board)desel()});

// ════════════════════════════════════════════════════
//  PIN
// ════════════════════════════════════════════════════
function togglePin(id){
  const item=items.find(i=>i.id===id);if(!item)return;
  item.pinned=!item.pinned;
  item.el.classList.toggle('pinned',item.pinned);
  const ph=item.el.querySelector('.pin-head');
  if(ph){ph.style.boxShadow=item.pinned?'inset 0 -2px 3px rgba(0,0,0,.5),0 2px 10px rgba(255,200,0,.7)':'inset 0 -2px 3px rgba(0,0,0,.5),0 2px 6px rgba(0,0,0,.7)'}
}

// ════════════════════════════════════════════════════
//  CLONE
// ════════════════════════════════════════════════════
function cloneItem(id){
  const item=items.find(i=>i.id===id);if(!item)return;
  const d=JSON.parse(JSON.stringify(item.data));
  if(item.type==='note') d.text=item.el.querySelector('.ntxt')?.textContent||d.text;
  if(item.type==='doc'){d.title=item.el.querySelector('.dtitle')?.textContent;d.body=item.el.querySelector('.dbody')?.textContent}
  mkItem(item.type,item.x+30,item.y+30,d);
}

// ════════════════════════════════════════════════════
//  REMOVE
// ════════════════════════════════════════════════════
function removeItem(id){
  const idx=items.findIndex(i=>i.id===id);if(idx<0)return;
  items[idx].el.remove();items.splice(idx,1);
  strings=strings.filter(s=>{
    if(s.from===id||s.to===id){s.labelEl?.remove();return false}return true;
  });
  redraw();if(selId===id)selId=null;
}
function delSelected(){if(selId)removeItem(selId)}
function clearBoard(){
  if(!confirm('Limpar todo o quadro?'))return;
  items.forEach(i=>i.el.remove());
  strings.forEach(s=>s.labelEl?.remove());
  items=[];strings=[];
  board.style.width='5000px';board.style.height='4000px';
  cv.width=5000;cv.height=4000;cv.style.width='5000px';cv.style.height='4000px';
  ctx.clearRect(0,0,cv.width,cv.height);
}

// ════════════════════════════════════════════════════
//  LABEL EDIT
// ════════════════════════════════════════════════════
function openLbl(id){
  lblTarget=id;
  const item=items.find(i=>i.id===id);
  document.getElementById('lblVal').value=item?.el.querySelector('.plabel')?.textContent||'';
  new bootstrap.Modal(document.getElementById('mLbl')).show();
}
function confirmLbl(){
  const item=items.find(i=>i.id===lblTarget);
  if(item){const l=item.el.querySelector('.plabel');if(l)l.textContent=document.getElementById('lblVal').value}
  bootstrap.Modal.getInstance(document.getElementById('mLbl')).hide();
}

// ════════════════════════════════════════════════════
//  STRING MODE
// ════════════════════════════════════════════════════
function toggleStrMode(){
  strMode=!strMode;
  document.getElementById('btn-str').classList.toggle('on',strMode);
  document.getElementById('hud-mode').style.display=strMode?'block':'none';
  board.classList.toggle('sm',strMode);
  strDrawing=false;strTemp=null;strFrom=null;redraw();
}

function startStr(fromId,e){
  e.preventDefault();e.stopPropagation();
  strDrawing=true;
  const p=bpos(e);strFrom={id:fromId,pos:p};
  strTemp={start:p,end:p,color:document.getElementById('str-color').value,width:parseFloat(document.getElementById('str-w').value)};
}

board.addEventListener('mouseup',e=>{
  if(!strMode||!strDrawing)return;
  const itemEl=e.target.closest('.bitem');
  if(itemEl&&strFrom&&itemEl.id!==strFrom.id){
    pendStr={from:strFrom.id,to:itemEl.id,color:document.getElementById('str-color').value,width:parseFloat(document.getElementById('str-w').value)};
    strDrawing=false;strTemp=null;strFrom=null;redraw();
    document.getElementById('strCmt').value='';
    new bootstrap.Modal(document.getElementById('mStr')).show();
  }else{
    strDrawing=false;strTemp=null;strFrom=null;redraw();
  }
});

function cancelStr(){pendStr=null}
function confirmStr(){
  if(!pendStr)return;
  const cmt=document.getElementById('strCmt').value.trim();
  const sid='s'+(idN++);
  const labelEl=cmt?mkStrLabel(cmt):null;
  strings.push({...pendStr,id:sid,comment:cmt,labelEl});
  pendStr=null;
  bootstrap.Modal.getInstance(document.getElementById('mStr')).hide();
  redraw();
}

function mkStrLabel(txt){
  const el=document.createElement('div');
  el.className='slabel';el.textContent=txt;
  const initRot = Math.random()*8-4;
  el.style.setProperty('--r', initRot+'deg');
  el._seState = {fs:11, rot:initRot, w:130, color:'#2a1000', bg:'#ffe55a'};
  el.addEventListener('dblclick',e=>{
    e.stopPropagation();
    const nw=prompt('Editar comentário:',el.textContent);
    if(nw!==null)el.textContent=nw;
  });
  el.addEventListener('mousedown',e=>e.stopPropagation());
  el.addEventListener('contextmenu',e=>{
    e.preventDefault();e.stopPropagation();
    openSLabelEditor(el, e.clientX, e.clientY);
  });
  board.appendChild(el);return el;
}

// ── SLABEL EDITOR LOGIC ──
let _seTarget = null;
function openSLabelEditor(el, mx, my){
  _seTarget = el;
  const s = el._seState;
  document.getElementById('se-fs-val').textContent = s.fs;
  document.getElementById('se-rot-val').textContent = Math.round(s.rot)+'°';
  document.getElementById('se-w-val').textContent = s.w;
  document.getElementById('se-color').value = s.color;
  document.getElementById('se-bg').value = s.bg;
  const ed = document.getElementById('slabel-editor');
  ed.style.display = 'block';
  // position near click
  const ex = Math.min(mx, window.innerWidth - 260);
  const ey = Math.min(my, window.innerHeight - 280);
  ed.style.left = ex + 'px';
  ed.style.top = ey + 'px';
}
function closeSLabelEditor(){ document.getElementById('slabel-editor').style.display='none'; _seTarget=null; }
function _seApply(){
  if(!_seTarget)return;
  const s = _seTarget._seState;
  _seTarget.style.fontSize = s.fs + 'px';
  _seTarget.style.transform = 'translate(-50%,-50%) rotate('+s.rot+'deg)';
  _seTarget.style.maxWidth = s.w + 'px';
  _seTarget.style.color = s.color;
  _seTarget.style.background = s.bg;
  document.getElementById('se-fs-val').textContent = s.fs;
  document.getElementById('se-rot-val').textContent = Math.round(s.rot)+'°';
  document.getElementById('se-w-val').textContent = s.w;
}
function seFontSize(d){ if(!_seTarget)return; _seTarget._seState.fs = Math.max(8, Math.min(48, _seTarget._seState.fs + d)); _seApply(); }
function seRotate(d){ if(!_seTarget)return; _seTarget._seState.rot += d; _seApply(); }
function seWidth(d){ if(!_seTarget)return; _seTarget._seState.w = Math.max(60, Math.min(400, _seTarget._seState.w + d)); _seApply(); }
function seTextColor(v){ if(!_seTarget)return; _seTarget._seState.color = v; _seApply(); }
function seBgColor(v){ if(!_seTarget)return; _seTarget._seState.bg = v; _seApply(); }
function seReset(){ if(!_seTarget)return; _seTarget._seState = {fs:11, rot:Math.random()*8-4, w:130, color:'#2a1000', bg:'#ffe55a'}; _seApply(); }

// ════════════════════════════════════════════════════
//  DRAW STRINGS
// ════════════════════════════════════════════════════
function redraw(){
  ctx.clearRect(0,0,cv.width,cv.height);

  if(strTemp)drawLine(strTemp.start,strTemp.end,strTemp.color,strTemp.width,true);

  strings.forEach(s=>{
    const f=items.find(i=>i.id===s.from);
    const t=items.find(i=>i.id===s.to);
    if(!f||!t)return;
    const p1=iCenter(f),p2=iCenter(t);
    drawLine(p1,p2,s.color,s.width,false);
    if(s.labelEl){
      s.labelEl.style.left=(p1.x+p2.x)/2+'px';
      s.labelEl.style.top=(p1.y+p2.y)/2+'px';
    }
  });
}

function drawLine(p1,p2,color,w,dash){
  const dx=p2.x-p1.x,dy=p2.y-p1.y;
  const sag=Math.sqrt(dx*dx+dy*dy)*0.06;
  const mx=(p1.x+p2.x)/2+(-dy/Math.sqrt(dx*dx+dy*dy||1))*sag*(Math.random()>.5?1:-1);
  const my=(p1.y+p2.y)/2+(dx/Math.sqrt(dx*dx+dy*dy||1))*sag*(Math.random()>.5?1:-1);

  ctx.save();
  ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.quadraticCurveTo(mx,my,p2.x,p2.y);
  ctx.strokeStyle=color;ctx.lineWidth=w;ctx.lineCap='round';
  if(dash)ctx.setLineDash([10,5]);else ctx.setLineDash([]);
  ctx.shadowColor='rgba(0,0,0,.5)';ctx.shadowBlur=4;ctx.shadowOffsetY=2;
  ctx.stroke();
  if(!dash){
    ctx.setLineDash([]);ctx.shadowBlur=0;ctx.fillStyle=color;
    [p1,p2].forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,w*1.6,0,Math.PI*2);ctx.fill()});
  }
  ctx.restore();
}

// ════════════════════════════════════════════════════
//  AUTO EXPAND BOARD
// ════════════════════════════════════════════════════
let _expandTimer = null;
function autoExpand(){
  clearTimeout(_expandTimer);
  _expandTimer = setTimeout(()=>{
    let maxX = 2000, maxY = 2000;
    items.forEach(i=>{
      const w = i.el.offsetWidth  || 250;
      const h = i.el.offsetHeight || 250;
      maxX = Math.max(maxX, i.x + w);
      maxY = Math.max(maxY, i.y + h);
    });
    const margin  = 800; // espaço extra após o último item
    const curW    = parseInt(board.style.width)  || 5000;
    const curH    = parseInt(board.style.height) || 4000;
    const newW    = Math.max(curW, maxX + margin);
    const newH    = Math.max(curH, maxY + margin);
    if(newW !== curW || newH !== curH){
      board.style.width  = newW + 'px';
      board.style.height = newH + 'px';
      cv.width           = newW;
      cv.height          = newH;
      cv.style.width     = newW + 'px';
      cv.style.height    = newH + 'px';
      redraw();
    }
  }, 80);
}

// ════════════════════════════════════════════════════
//  ADD PHOTO
// ════════════════════════════════════════════════════
let pendPhotoUrl=null;
function openAddPhoto(){
  pendPhotoUrl=null;
  document.getElementById('pUrl').value='';document.getElementById('pLbl').value='';
  document.getElementById('upzone').innerHTML='<i class="bi bi-cloud-upload fs-1 d-block mb-2"></i>Clique ou <strong>arraste</strong> uma imagem aqui<br><small style="color:#8B5A2B">JPG · PNG · GIF · WEBP</small>';
  new bootstrap.Modal(document.getElementById('mPhoto')).show();
}
function pickFile(e){doUpload(e.target.files[0])}
function dropFile(e){e.preventDefault();e.target.classList.remove('dv');doUpload(e.dataTransfer.files[0])}
function doUpload(file){
  if(!file)return;
  // Try server upload first
  const fd=new FormData();fd.append('imagem',file);
  fetch('index.php',{method:'POST',body:fd})
    .then(r=>r.json())
    .then(d=>{
      if(d.success){
        pendPhotoUrl=d.url;
        document.getElementById('pUrl').value=d.url;
        document.getElementById('upzone').innerHTML=`<i class="bi bi-check-circle-fill text-success fs-1 d-block mb-2"></i><strong>${file.name}</strong><br><small style="color:#6b3">Upload OK!</small>`;
      }else throw new Error(d.msg||'Erro');
    })
    .catch(()=>{
      // Fallback: local object URL (won't save, but shows preview)
      pendPhotoUrl=URL.createObjectURL(file);
      document.getElementById('pUrl').value='[local]';
      document.getElementById('upzone').innerHTML=`<i class="bi bi-check-circle-fill text-warning fs-1 d-block mb-2"></i><strong>${file.name}</strong><br><small style="color:#cc8">Pré-visualização local (crie a pasta uploads/ no servidor para salvar)</small>`;
    });
}
function confirmPhoto(){
  const url=pendPhotoUrl||document.getElementById('pUrl').value.trim();
  if(!url){alert('Selecione ou informe uma imagem!');return}
  const lbl=document.getElementById('pLbl').value.trim();
  const cx=(-panX+wrap.clientWidth/2)/zoom;
  const cy=(-panY+wrap.clientHeight/2)/zoom;
  mkItem('photo',cx-100+(Math.random()*120-60),cy-90+(Math.random()*120-60),{url,label:lbl});
  bootstrap.Modal.getInstance(document.getElementById('mPhoto')).hide();
  pendPhotoUrl=null;
}

function addNote(){
  const cx=(-panX+wrap.clientWidth/2)/zoom;
  const cy=(-panY+wrap.clientHeight/2)/zoom;
  mkItem('note',cx-84+(Math.random()*100-50),cy-65+(Math.random()*100-50),{text:'Nova nota...'});
}
function addDoc(){
  const cx=(-panX+wrap.clientWidth/2)/zoom;
  const cy=(-panY+wrap.clientHeight/2)/zoom;
  mkItem('doc',cx-105+(Math.random()*100-50),cy-90+(Math.random()*100-50),{title:'RELATÓRIO',body:'Clique para editar o conteúdo deste documento...'});
}
function addNoteAt(){mkItem('note',ctxMenuPos.x-84,ctxMenuPos.y-65,{text:'Nova nota...'})}
function addDocAt(){mkItem('doc',ctxMenuPos.x-105,ctxMenuPos.y-90,{title:'RELATÓRIO',body:'Conteúdo...'})}

// ════════════════════════════════════════════════════
//  SAVE / LOAD
// ════════════════════════════════════════════════════
function saveBoard(){
  const data={
    zoom,panX,panY,
    items:items.map(i=>({
      id:i.id,x:i.x,y:i.y,rot:i.rot||0,type:i.type,pinned:i.pinned,
      itemScale:i.itemScale||1,textColor:i.textColor||null,fontSize:i.fontSize||null,innerW:i.innerW||null,innerH:i.innerH||null,
      data:i.type==='photo'
        ?{url:i.el.querySelector('img')?.src,label:i.el.querySelector('.plabel')?.textContent}
        :i.type==='note'?{text:i.el.querySelector('.ntxt')?.textContent}
        :{title:i.el.querySelector('.dtitle')?.textContent,body:i.el.querySelector('.dbody')?.textContent}
    })),
    strings:strings.map(s=>({from:s.from,to:s.to,color:s.color,width:s.width,comment:s.comment,seState:s.labelEl?s.labelEl._seState:null}))
  };
  const a=Object.assign(document.createElement('a'),{
    href:'data:application/json,'+encodeURIComponent(JSON.stringify(data,null,2)),
    download:'quadro_investigador.json'
  });a.click();
}

function loadBoardFile(){
  const inp=Object.assign(document.createElement('input'),{type:'file',accept:'.json'});
  inp.onchange=e=>{
    const fr=new FileReader();
    fr.onload=ev=>{
      try{
        const data=JSON.parse(ev.target.result);
        clearBoard();idN=1;
        const idMap={};
        data.items.forEach(i=>{
          const obj=mkItem(i.type,i.x,i.y,i.data);
          obj.rot=i.rot;obj.itemScale=i.itemScale||1;applyItemTransform(obj);
          if(i.innerW){obj.innerW=i.innerW;}if(i.innerH){obj.innerH=i.innerH;}if(i.innerW||i.innerH)applyInnerSize(obj);
          if(i.pinned)togglePin(obj.id);
          if(i.textColor)changeTextColor(obj.id,i.textColor);
          if(i.fontSize)changeFontSize(obj.id,0);// restore via fontSize stored in item
          idMap[i.id]=obj.id;
        });
        data.strings?.forEach(s=>{
          const f=idMap[s.from],t=idMap[s.to];
          if(!f||!t)return;
          {const lbl=s.comment?mkStrLabel(s.comment):null; if(lbl&&s.seState){lbl._seState=Object.assign(lbl._seState,s.seState);lbl.style.fontSize=lbl._seState.fs+'px';lbl.style.transform='translate(-50%,-50%) rotate('+lbl._seState.rot+'deg)';lbl.style.maxWidth=lbl._seState.w+'px';lbl.style.color=lbl._seState.color;lbl.style.background=lbl._seState.bg;} strings.push({id:'s'+(idN++),from:f,to:t,color:s.color,width:s.width,comment:s.comment,labelEl:lbl});}
        });
        if(data.zoom){zoom=data.zoom;panX=data.panX;panY=data.panY;applyT()}
        redraw();autoExpand();
      }catch(err){alert('Erro ao carregar: '+err.message)}
    };
    fr.readAsText(e.target.files[0]);
  };
  inp.click();
}

// ════════════════════════════════════════════════════
//  INIT — demo content
// ════════════════════════════════════════════════════
window.addEventListener('load',()=>{
  // Try to restore autosaved progress
  if(localStorage.getItem('quadro_investigador_autosave')){
    if(quickLoad()) return; // restored OK, skip demo
  }
  const n1=mkItem('note',260,180,{text:'📌 COMO USAR:\n• Foto → adicionar imagem\n• Nota → post-it editável\n• Doc → documento/recorte\n• Fio → conectar itens\n• Drag para mover\n• Clique direito no quadro'});
  const n2=mkItem('note',650,120,{text:'🔍 ATALHOS:\nScroll → Zoom\nMouse Meio → Pan\nEspaço+Drag → Pan\nDel → Excluir selecionado\nESC → Cancelar modo'});
  const d1=mkItem('doc',430,220,{title:'CASO #001 — ABERTO',body:'Data: 15/04/2026\nLocal: Desconhecido\nInvestigador: ___\nStatus: EM INVESTIGAÇÃO\nSuspeitos: 0\nEvidências: 0'});
  redraw();
});

// ════════════════════════════════════════════════════
//  AUTO SAVE / CTRL+S
// ════════════════════════════════════════════════════
function boardToData(){
  return{
    zoom,panX,panY,
    items:items.map(i=>({
      id:i.id,x:i.x,y:i.y,rot:i.rot||0,type:i.type,pinned:i.pinned,
      itemScale:i.itemScale||1,textColor:i.textColor||null,fontSize:i.fontSize||null,
      innerW:i.innerW||null,innerH:i.innerH||null,
      data:i.type==='photo'
        ?{url:i.el.querySelector('img')?.src,label:i.el.querySelector('.plabel')?.textContent}
        :i.type==='note'?{text:i.el.querySelector('.ntxt')?.textContent}
        :{title:i.el.querySelector('.dtitle')?.textContent,body:i.el.querySelector('.dbody')?.textContent}
    })),
    strings:strings.map(s=>({from:s.from,to:s.to,color:s.color,width:s.width,comment:s.comment,seState:s.labelEl?s.labelEl._seState:null}))
  };
}

function quickSave(){
  try{
    localStorage.setItem('quadro_investigador_autosave', JSON.stringify(boardToData()));
    const t=document.getElementById('toast-save');
    t.classList.add('show');
    clearTimeout(window._toastT);
    window._toastT=setTimeout(()=>t.classList.remove('show'),2000);
  }catch(e){console.warn('Autosave falhou:',e);}
}

function quickLoad(){
  try{
    const raw=localStorage.getItem('quadro_investigador_autosave');
    if(!raw) return false;
    const data=JSON.parse(raw);
    clearBoard();idN=1;
    const idMap={};
    data.items.forEach(i=>{
      const obj=mkItem(i.type,i.x,i.y,i.data);
      obj.rot=i.rot;obj.itemScale=i.itemScale||1;applyItemTransform(obj);
      if(i.innerW){obj.innerW=i.innerW;}if(i.innerH){obj.innerH=i.innerH;}
      if(i.innerW||i.innerH) applyInnerSize(obj);
      if(i.pinned)togglePin(obj.id);
      if(i.textColor)changeTextColor(obj.id,i.textColor);
      idMap[i.id]=obj.id;
    });
    data.strings?.forEach(s=>{
      const f=idMap[s.from],t=idMap[s.to];
      if(!f||!t)return;
      {const lbl=s.comment?mkStrLabel(s.comment):null; if(lbl&&s.seState){lbl._seState=Object.assign(lbl._seState,s.seState);lbl.style.fontSize=lbl._seState.fs+'px';lbl.style.transform='translate(-50%,-50%) rotate('+lbl._seState.rot+'deg)';lbl.style.maxWidth=lbl._seState.w+'px';lbl.style.color=lbl._seState.color;lbl.style.background=lbl._seState.bg;} strings.push({id:'s'+(idN++),from:f,to:t,color:s.color,width:s.width,comment:s.comment,labelEl:lbl});}
    });
    if(data.zoom){zoom=data.zoom;panX=data.panX;panY=data.panY;applyT();}
    redraw();autoExpand();
    return true;
  }catch(e){console.warn('Autorestore falhou:',e);return false;}
}

// Ctrl+S → quick save
document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key==='s'){
    const hcs=document.getElementById('hud-ctrlsave');
    hcs.innerHTML='✓ Salvo!';hcs.style.color='#5ddf7a';hcs.style.borderColor='#2a6b10';
    setTimeout(()=>{hcs.innerHTML='<kbd>Ctrl</kbd>+<kbd>S</kbd> Salvar progresso';hcs.style.color='';hcs.style.borderColor='';},1800);
    e.preventDefault();
    quickSave();
  }
});

applyT();
</script>
</body>
</html>
